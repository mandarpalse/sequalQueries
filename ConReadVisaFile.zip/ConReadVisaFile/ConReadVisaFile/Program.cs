﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConReadVisaFile
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string filePath = @"C:\Users\mandar.palse\OneDrive - INDIA1 PAYMENTS LTD\Desktop\Data\Sampledata.txt";

            List<string> records = new List<string>();

            string previous4600Line = null;

            using (FileStream fs = new FileStream(
                filePath, FileMode.Open, FileAccess.Read))
            using (StreamReader reader = new StreamReader(fs))
            {
                string line;

                while ((line = reader.ReadLine()) != null)
                {
                    // Process 4600 record
                    if (line.StartsWith("4600"))
                    {
                        // Reset the previous record
                        previous4600Line = null;

                        // Check the 59th character is '4'
                        if (line.Length >= 59 && line[59] == '4')
                        {
                            previous4600Line = line;

                            string nextLine = reader.ReadLine();

                            if (nextLine != null)
                            {
                                string combined = line + nextLine;

                                // Pad with spaces on the right to 168 characters
                                if (combined.Length < 168)
                                {
                                    combined = combined.PadRight(168);
                                }

                                if (combined.Length == 168)
                                {
                                    records.Add(combined);
                                }
                                else
                                {
                                    Console.WriteLine(
                                        $"4600 record exceeds 168 characters: {combined.Length}");
                                }
                            }
                            else
                            {
                                previous4600Line = null;
                            }
                        }
                    }
                    // Process 4601 record
                    else if (line.StartsWith("4601"))
                    {
                        if (previous4600Line != null &&
                            previous4600Line.Length >= 59 &&
                            previous4600Line[59] == '4')
                        {
                            string nextLine = reader.ReadLine();

                            if (nextLine != null)
                            {
                                string combined = line + nextLine;

                                // Pad with spaces on the right to 168 characters
                                if (combined.Length < 168)
                                {
                                    combined = combined.PadRight(168);
                                }

                                if (combined.Length == 168)
                                {
                                    records.Add(combined);
                                }
                                else
                                {
                                    Console.WriteLine(
                                        $"4601 record exceeds 168 characters: {combined.Length}");
                                }
                            }
                        }

                        // Reset after processing 4601
                        previous4600Line = null;
                    }
                }
            }

            // Convert List<string> to string array
            string[] resultArray = records.ToArray();

            Console.WriteLine("Total records: " + resultArray.Length);

            foreach (string record in resultArray)
            {
                Console.WriteLine(record);
                Console.WriteLine("Length: " + record.Length);
            }



            List<TC00Model> tc00Records = new List<TC00Model>();
            List<TC01Model> tc01Records = new List<TC01Model>();

            foreach (string record in resultArray)
            {
                if (record.StartsWith("4600"))
                {
                    tc00Records.Add(RecordMapper.MapTC00(record));
                }
                else if (record.StartsWith("4601"))
                {
                    tc01Records.Add(RecordMapper.MapTC01(record));
                }
            }

            List<string> tcStrRecords = new List<string>();

            foreach (string record in resultArray)
            {
                if (record.StartsWith("4600"))
                {
                    tcStrRecords.Add(RecordMapper.StrMapTC00(record));
                }
                else if (record.StartsWith("4601"))
                {
                    tcStrRecords.Add(RecordMapper.StrMapTC01(record));
                }
            }

            for (int i = 0; i < tcStrRecords.Count; i++)
            {
                Console.WriteLine(tcStrRecords[i]);
            }


            Console.ReadLine();
        }
    }
}
