﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConReadVisaFile
{
    public class TC01Model
    {
        public string TransactionCode { get; set; }              // 1-2
        public string TransactionCodeQualifier { get; set; }     // 3
        public string TransactionComponentSequenceNumber { get; set; } // 4

        public string RateTableID { get; set; }                  // 5-9
        public string Reserved1 { get; set; }                    // 10-11

        public string FirstCount { get; set; }                   // 12-26
        public string SecondCount { get; set; }                  // 27-41

        public string FirstAmount { get; set; }                  // 42-56
        public string FirstAmountSign { get; set; }              // 57-58

        public string SecondAmount { get; set; }                 // 59-73
        public string SecondAmountSign { get; set; }             // 74-75

        public string ThirdAmount { get; set; }                  // 76-90
        public string ThirdAmountSign { get; set; }              // 91-92

        public string FourthAmount { get; set; }                 // 93-107
        public string FourthAmountSign { get; set; }             // 108-109

        public string FifthAmount { get; set; }                  // 110-124
        public string FifthAmountSign { get; set; }              // 125-126

        public string SixthAmount { get; set; }                  // 127-141
        public string SixthAmountSign { get; set; }              // 142-143

        public string Reserved2 { get; set; }                    // 144-168
    }
}
