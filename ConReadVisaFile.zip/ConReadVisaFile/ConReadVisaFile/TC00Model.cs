﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConReadVisaFile
{
    public class TC00Model
    {
        public string TransactionCode { get; set; }             // 1-2
        public string TransactionCodeQualifier { get; set; }    // 3
        public string TransactionComponentSequenceNumber { get; set; } // 4

        public string DestinationIdentifier { get; set; }       // 5-10
        public string SourceIdentifier { get; set; }            // 11-16

        public string ReportingForSREIdentifier { get; set; }   // 17-26
        public string RollupToSREIdentifier { get; set; }       // 27-36
        public string FundsTransferSREIdentifier { get; set; }  // 37-46

        public string SettlementServiceIdentifier { get; set; } // 47-49
        public string SettlementCurrencyCode { get; set; }       // 50-52
        public string ClearingCurrencyCode { get; set; }         // 53-55

        public string BusinessMode { get; set; }                // 56
        public string NoDataIndicator { get; set; }             // 57
        public string Reserved1 { get; set; }                   // 58
        public string ReportGroup { get; set; }                 // 59
        public string ReportSubgroup { get; set; }              // 60

        public string ReportIdentificationNumber { get; set; }  // 61-63
        public string ReportIdentificationSuffix { get; set; }  // 64-65

        public string SettlementDate { get; set; }              // 66-72
        public string ReportDate { get; set; }                  // 73-79
        public string FromDate { get; set; }                     // 80-86
        public string ToDate { get; set; }                       // 87-93

        public string ChargeTypeCode { get; set; }              // 94-96
        public string BusinessTransactionType { get; set; }     // 97-99
        public string BusinessTransactionCycle { get; set; }    // 100
        public string ReversalIndicator { get; set; }           // 101
        public string ReturnIndicator { get; set; }             // 102

        public string JurisdictionCode { get; set; }            // 103-104
        public string InterregionalRoutingIndicator { get; set; }// 105
        public string SourceCountryCode { get; set; }            // 106-108
        public string DestinationCountryCode { get; set; }       // 109-111
        public string SourceRegionCode { get; set; }             // 112-113
        public string DestinationRegionCode { get; set; }        // 114-115

        public string FeeLevelDescriptor { get; set; }           // 116-131
        public string CreditDebitNetIndicator { get; set; }      // 132
        public string SummaryLevel { get; set; }                 // 133-134

        public string Reserved2 { get; set; }                    // 135-136
        public string Reserved3 { get; set; }                    // 137-167
        public string ReimbursementAttribute { get; set; }       // 168
    }
}
