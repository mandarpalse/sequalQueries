﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConReadVisaFile
{
    public static class RecordMapper
    {
        public static TC00Model MapTC00(string record)
        {
            if (record == null || record.Length != 168)
                throw new ArgumentException("TC00 record must be 168 characters.");

            return new TC00Model
            {
                TransactionCode = record.Substring(0, 2),
                TransactionCodeQualifier = record.Substring(2, 1),
                TransactionComponentSequenceNumber = record.Substring(3, 1),

                DestinationIdentifier = record.Substring(4, 6),
                SourceIdentifier = record.Substring(10, 6),

                ReportingForSREIdentifier = record.Substring(16, 10),
                RollupToSREIdentifier = record.Substring(26, 10),
                FundsTransferSREIdentifier = record.Substring(36, 10),

                SettlementServiceIdentifier = record.Substring(46, 3),
                SettlementCurrencyCode = record.Substring(49, 3),
                ClearingCurrencyCode = record.Substring(52, 3),

                BusinessMode = record.Substring(55, 1),
                NoDataIndicator = record.Substring(56, 1),
                Reserved1 = record.Substring(57, 1),
                ReportGroup = record.Substring(58, 1),
                ReportSubgroup = record.Substring(59, 1),

                ReportIdentificationNumber = record.Substring(60, 3),
                ReportIdentificationSuffix = record.Substring(63, 2),

                SettlementDate = record.Substring(65, 7),
                ReportDate = record.Substring(72, 7),
                FromDate = record.Substring(79, 7),
                ToDate = record.Substring(86, 7),

                ChargeTypeCode = record.Substring(93, 3),
                BusinessTransactionType = record.Substring(96, 3),
                BusinessTransactionCycle = record.Substring(99, 1),
                ReversalIndicator = record.Substring(100, 1),
                ReturnIndicator = record.Substring(101, 1),

                JurisdictionCode = record.Substring(102, 2),
                InterregionalRoutingIndicator = record.Substring(104, 1),
                SourceCountryCode = record.Substring(105, 3),
                DestinationCountryCode = record.Substring(108, 3),
                SourceRegionCode = record.Substring(111, 2),
                DestinationRegionCode = record.Substring(113, 2),

                FeeLevelDescriptor = record.Substring(115, 16),
                CreditDebitNetIndicator = record.Substring(131, 1),
                SummaryLevel = record.Substring(132, 2),

                Reserved2 = record.Substring(134, 2),
                Reserved3 = record.Substring(136, 31),
                ReimbursementAttribute = record.Substring(167, 1)
            };
        }

        public static TC01Model MapTC01(string record)
        {
            if (record == null || record.Length != 168)
                throw new ArgumentException("TC01 record must be 168 characters.");

            return new TC01Model
            {
                TransactionCode = record.Substring(0, 2),
                TransactionCodeQualifier = record.Substring(2, 1),
                TransactionComponentSequenceNumber = record.Substring(3, 1),

                RateTableID = record.Substring(4, 5),
                Reserved1 = record.Substring(9, 2),

                FirstCount = record.Substring(11, 15),
                SecondCount = record.Substring(26, 15),

                FirstAmount = record.Substring(41, 15),
                FirstAmountSign = record.Substring(56, 2),

                SecondAmount = record.Substring(58, 15),
                SecondAmountSign = record.Substring(73, 2),

                ThirdAmount = record.Substring(75, 15),
                ThirdAmountSign = record.Substring(90, 2),

                FourthAmount = record.Substring(92, 15),
                FourthAmountSign = record.Substring(107, 2),

                FifthAmount = record.Substring(109, 15),
                FifthAmountSign = record.Substring(124, 2),

                SixthAmount = record.Substring(126, 15),
                SixthAmountSign = record.Substring(141, 2),

                Reserved2 = record.Substring(143, 25)
            };
        }


        public static string StrMapTC00(string record)
        {
            if (record == null || record.Length != 168)
                throw new ArgumentException("TC00 record must be exactly 168 characters.");

            return string.Join("|", new string[]
            {
            record.Substring(0, 2),    // Transaction Code
            record.Substring(2, 1),    // Transaction Code Qualifier
            record.Substring(3, 1),    // Transaction Component Sequence Number
            record.Substring(4, 6),    // Destination Identifier
            record.Substring(10, 6),   // Source Identifier
            record.Substring(16, 10),  // Reporting for SRE Identifier
            record.Substring(26, 10),  // Rollup to SRE Identifier
            record.Substring(36, 10),  // Funds Transfer SRE Identifier
            record.Substring(46, 3),   // Settlement Service Identifier
            record.Substring(49, 3),   // Settlement Currency Code
            record.Substring(52, 3),   // Clearing Currency Code
            record.Substring(55, 1),   // Business Mode
            record.Substring(56, 1),   // No Data Indicator
            record.Substring(57, 1),   // Reserved
            record.Substring(58, 1),   // Report Group
            record.Substring(59, 1),   // Report Subgroup
            record.Substring(60, 3),   // Report Identification Number
            record.Substring(63, 2),   // Report Identification Suffix
            record.Substring(65, 7),   // Settlement Date
            record.Substring(72, 7),   // Report Date
            record.Substring(79, 7),   // From Date
            record.Substring(86, 7),   // To Date
            record.Substring(93, 3),   // Charge Type Code
            record.Substring(96, 3),   // Business Transaction Type
            record.Substring(99, 1),   // Business Transaction Cycle
            record.Substring(100, 1),  // Reversal Indicator
            record.Substring(101, 1),  // Return Indicator
            record.Substring(102, 2),  // Jurisdiction Code
            record.Substring(104, 1),  // Interregional Routing Indicator
            record.Substring(105, 3),  // Source Country Code
            record.Substring(108, 3),  // Destination Country Code
            record.Substring(111, 2),  // Source Region Code
            record.Substring(113, 2),  // Destination Region Code
            record.Substring(115, 16), // Fee Level Descriptor
            record.Substring(131, 1),  // CR/DB/NET Indicator
            record.Substring(132, 2),  // Summary Level
            record.Substring(134, 2),  // Reserved
            record.Substring(136, 31), // Reserved
            record.Substring(167, 1)   // Reimbursement Attribute
            });
        }

        public static string StrMapTC01(string record)
        {
            if (record == null || record.Length != 168)
                throw new ArgumentException("TC01 record must be exactly 168 characters.");

            return string.Join("|", new string[]
            {
            record.Substring(0, 2),    // Transaction Code
            record.Substring(2, 1),    // Transaction Code Qualifier
            record.Substring(3, 1),    // Transaction Component Sequence Number
            record.Substring(4, 5),    // Rate Table ID
            record.Substring(9, 2),    // Reserved
            record.Substring(11, 15),  // First Count
            record.Substring(26, 15),  // Second Count
            record.Substring(41, 15),  // First Amount
            record.Substring(56, 2),   // First Amount Sign
            record.Substring(58, 15),  // Second Amount
            record.Substring(73, 2),   // Second Amount Sign
            record.Substring(75, 15),  // Third Amount
            record.Substring(90, 2),   // Third Amount Sign
            record.Substring(92, 15),  // Fourth Amount
            record.Substring(107, 2),  // Fourth Amount Sign
            record.Substring(109, 15), // Fifth Amount
            record.Substring(124, 2),  // Fifth Amount Sign
            record.Substring(126, 15), // Sixth Amount
            record.Substring(141, 2),  // Sixth Amount Sign
            record.Substring(143, 25)  // Reserved
            });
        }

    }

}
